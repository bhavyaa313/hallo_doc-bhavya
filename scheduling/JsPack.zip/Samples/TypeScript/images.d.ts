declare module '*.png';
declare module '*.svg';
declare module '*.txt';
declare module '*.css';
declare module '*.json';